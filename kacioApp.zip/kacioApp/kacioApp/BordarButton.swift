//
//  BordarButton.swift
//  kacioApp
//
//  Created by Turma Tarde on 4/19/18.
//  Copyright © 2018 Ailton Lessa. All rights reserved.
//

import UIKit

class BordarButton: UIButton {

  override func awakeFromNib() {
    super.awakeFromNib()
    layer.borderWidth = 3.0
    layer.borderColor = UIColor.green.cgColor
  }
}
